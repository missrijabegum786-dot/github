#!/system/bin/sh

RED='\033[1;31m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
BLUE='\033[1;34m'
PURPLE='\033[1;35m'
CYAN='\033[1;36m'
WHITE='\033[1;37m'
BG_RED='\033[41m'
BG_GREEN='\033[42m'
BG_YELLOW='\033[43m'
BG_BLUE='\033[44m'
BG_PURPLE='\033[45m'
BG_CYAN='\033[46m'
BG_WHITE='\033[47m'
BOLD='\033[1m'
UNDERLINE='\033[4m'
BLINK='\033[5m'
REVERSE='\033[7m'
NC='\033[0m'

print_color() {
    echo -e "${BG_BLUE}${WHITE}${BOLD} $1 ${NC}"
}

print_success() {
    echo -e "${BG_GREEN}${WHITE}${BOLD} ✓ $1 ${NC}"
}

print_warning() {
    echo -e "${BG_YELLOW}${BLACK}${BOLD} ⚠ $1 ${NC}"
}

print_error() {
    echo -e "${BG_RED}${WHITE}${BOLD} ✗ $1 ${NC}"
}

print_info() {
    echo -e "${BG_CYAN}${WHITE}${BOLD} ℹ $1 ${NC}"
}

print_header() {
    echo -e "${BG_PURPLE}${WHITE}${BOLD}"
    echo "╔══════════════════════════════════════════╗"
    echo "║           PUBG MOBILE 无限游客          ║"
    echo "║      官方Tele: @ xjzznb        ║"
    echo "╚══════════════════════════════════════════╝"
    echo -e "${NC}"
    echo
}

check_root_privileges() {
    print_info "检查Root权限..."
    if [ "$(id -u)" -ne 0 ]; then
        print_error "错误: 需要root权限运行此脚本"
        echo -e "${YELLOW}请以root用户身份运行此脚本${NC}"
        exit 1
    fi
    print_success "Root权限检查通过"
}

show_progress() {
    local pid=$1
    local text=$2
    local delay=0.1
    local spinstr='|/-\'
    
    echo -n -e "${CYAN}${BOLD} $text... ${NC}"
    while [ "$(ps a | awk '{print $1}' | grep $pid)" ]; do
        local temp=${spinstr#?}
        printf " [%c]  " "$spinstr"
        local spinstr=$temp${spinstr%"$temp"}
        sleep $delay
        printf "\b\b\b\b\b\b"
    done
    printf "\b\b\b\b\b\b"
    print_success "$text 完成"
}

process_game() {
    local package_name="$1"
    local activity_name="$2"
    local data_path="$3"
    local game_name="$4"
    
    print_header
    echo -e "${BG_BLUE}${WHITE}${BOLD} 正在处理: $game_name ${NC}"
    echo -e "${CYAN}包名: $package_name${NC}"
    echo
    
    print_info "终止游戏进程..."
    kill $package_name 2>/dev/null &
    show_progress $! "终止进程"
    
    print_info "清理游戏数据..."
    (
        rm -rf $data_path/shared_prefs /storage/emulated/0/Documents/
        mkdir -p $data_path/shared_prefs
        chmod 777 $data_path/shared_prefs
        rm -rf $data_path/files
    ) &
    show_progress $! "清理数据目录"

    print_info "生成新的设备ID..."
    (
        local guest_file="$data_path/shared_prefs/device_id.xml"
        rm -rf $guest_file
        echo "<?xml version='1.0' encoding='utf-8' standalone='yes' ?>
<map>
    <string name=\"random\"></string>
    <string name=\"install\"></string>
    <string name=\"uuid\">$RANDOM$RANDOM-$RANDOM-$RANDOM-$RANDOM-$RANDOM$RANDOM$RANDOM</string>
</map>" > $guest_file
    ) &
    show_progress $! "生成设备ID"

    print_info "清理游戏缓存和库文件..."
    (
        rm -rf /data/app/~~zz-XL0BU7BYX1BLlcm7gyw==/$package_name-*/lib/arm64/libtgpa.so
        rm -rf /storage/emulated/0/Android/data/$package_name/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/MMKV
        rm -rf $data_path/databases
        rm -rf /data/media/0/Android/data/$package_name/files/login-identifier.txt
        rm -rf /data/media/0/Android/data/$package_name/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate
        mkdir -p /data/media/0/Android/data/$package_name/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/
        touch /data/media/0/Android/data/$package_name/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate
        rm -rf /data/media/0/Android/data/$package_name/files/TGPA
        mkdir -p /data/media/0/Android/data/$package_name/files/
        touch /data/media/0/Android/data/$package_name/files/TGPA
        rm -rf /data/media/0/Android/data/$package_name/files/ProgramBinaryCache
        touch /data/media/0/Android/data/$package_name/files/ProgramBinaryCache
    ) &
    show_progress $! "清理缓存文件"

    print_info "设置网络限制..."
    (
        iptables -I OUTPUT -d cloud.vmp.onezapp.com -j REJECT
        iptables -I INPUT -s cloud.vmp.onezapp.com -j REJECT
    ) &
    show_progress $! "网络限制设置"

    print_info "清理游客数据..."
    (
        local target_dir="/storage/emulated/0/Android/data/$package_name/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/MMKV"
        if [ -d "$target_dir" ]; then
            rm -rf "$target_dir"
            if [ $? -eq 0 ]; then
                echo "success" > /tmp/mmkv_result
            else
                echo "fail" > /tmp/mmkv_result
            fi
        else
            echo "not_exists" > /tmp/mmkv_result
        fi
    ) &
    show_progress $! "清理游客数据"
    
    if [ -f /tmp/mmkv_result ]; then
        local result=$(cat /tmp/mmkv_result)
        case $result in
            "success")
                print_success "游客数据已成功删除 + 限制注册"
                ;;
            "fail")
                print_error "删除游客数据失败"
                ;;
            "not_exists")
                print_warning "游客数据文件夹不存在"
                ;;
        esac
        rm -f /tmp/mmkv_result
    fi
    
    echo
    echo -e "${BG_GREEN}${WHITE}${BOLD} 🎉 $game_name 处理完成! ${NC}"
    echo -e "${YELLOW}${BOLD}等待0.3秒返回菜单...${NC}"
    sleep 0.3
}

main() {
    while true; do
        print_header
        echo -e "${BG_CYAN}${WHITE}${BOLD} 请选择游戏版本: ${NC}"
        echo
        PS3=$'\e[1;35m'"请选择操作 (1-5): "${NC}
        options=(
            "${GREEN}国际服 (Global)${NC}" 
            "${YELLOW}日韩服 (Korea/Japan)${NC}" 
            "${BLUE}台湾服 (Taiwan)${NC}" 
            "${RED}越南服 (Vietnam)${NC}" 
            "${PURPLE}退出程序${NC}"
        )
        
        select opt in "${options[@]}"; do
            case $REPLY in
                1)
                    process_game "com.tencent.ig" "com.epicgames.ue4.SplashActivity" \
                                "/data/data/com.tencent.ig" "PUBG MOBILE 国际服"
                    break
                    ;;
                2)
                    process_game "com.pubg.krmobile" "com.epicgames.ue4.SplashActivity" \
                                "/data/data/com.pubg.krmobile" "PUBG MOBILE 日韩服"
                    break
                    ;;
                3)
                    process_game "com.rekoo.pubgm" "com.epicgames.ue4.SplashActivity" \
                                "/data/data/com.rekoo.pubgm" "PUBG MOBILE 台湾服"
                    break
                    ;;
                4)
                    process_game "com.vng.pubgmobile" "com.epicgames.ue4.SplashActivity" \
                                "/data/data/com.vng.pubgmobile" "PUBG MOBILE 越南服"
                    break
                    ;;
                5)
                    print_header
                    echo -e "${BG_PURPLE}${WHITE}${BOLD}"
                    echo "╔══════════════════════════════════════════╗"
                    echo "║                感谢使用                  ║"
                    echo "║               香蕉爱你哟                 ║"
                    echo "╚══════════════════════════════════════════╝"
                    echo -e "${NC}"
                    echo -e "${GREEN}脚本已退出${NC}"
                    exit 0
                    ;;
                *)
                    print_error "无效选择，请输入 1-5 之间的数字"
                    sleep 0.1
                    break
                    ;;
            esac
        done
    done
}

print_header
check_root_privileges
sleep 0.5
main