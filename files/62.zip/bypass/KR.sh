#!/bin/bash

function print_color() {
  local color=$1
  shift
  echo -e "\033[${color}m$@\033[0m"
}

# صلاحيات الروت
if [ $(id -u) != 0 ]; then
    echo "\nPlease check form root!"
    exit 1
fi

sleep 0.3

echo -e "\033[1;33;40mTG-:@zxzrl\033[0m"
echo -e "\033[33;31m**************************************\033[0m"   	

sleep 0.2

cp -f libDoxKing.so /data/data/com.pubg.krmobile/
chmod 755 /data/data/com.pubg.krmobile/libDoxKing.so*

cp -f inject /data/data/com.pubg.krmobile/
chmod 777 /data/data/com.pubg.krmobile/inject*

# استدعاء المكتبة
if [ -f /data/data/com.pubg.krmobile/libDoxKing.so ] && [ "$(stat -c '%a' /data/data/com.pubg.krmobile/libDoxKing.so)" = "755" ]; then
    echo "[+] Dynamic mode Work"
else
    echo "[-] Dynamic mode NoWork"
    exit 1
fi

if [ -f /data/data/com.pubg.krmobile/inject ] && [ "$(stat -c '%a' /data/data/com.pubg.krmobile/inject)" = "777" ]; then
    echo "[+] libDoxKing.so Work ✅"
else
    echo "[-] libDoxKing.so NoWork ❌"
    exit 1
fi

echo -e "\n"

print_color 41 "Done load libDoxKing.so!"

echo -e "\n"

sleep 0.5

am start com.pubg.krmobile/com.epicgames.ue4.SplashActivity

sleep 2.0

echo -e "\n"

su -c /data/data/com.pubg.krmobile/inject -n com.pubg.krmobilece -so /data/data/com.pubg.krmobile/libDoxKing.so